import React, { useState } from 'react';

function App() {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [role, setRole] = useState('WORKER');
  const [message, setMessage] = useState('');
  const [token, setToken] = useState(localStorage.getItem('token'));

  const API_URL = 'http://localhost:3000/api';

  const handleSubmit = async (e) => {
    e.preventDefault();
    setMessage('');

    try {
      const endpoint = isLogin ? '/auth/login' : '/auth/register';
      const body = isLogin 
        ? { email, password }
        : { email, password, firstName, lastName, role };

      const response = await fetch(API_URL + endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      });

      const data = await response.json();

      if (response.ok) {
        setToken(data.accessToken);
        localStorage.setItem('token', data.accessToken);
        setMessage(\`Success! Welcome \${data.user.profile?.displayName || email}\`);
      } else {
        setMessage(data.error || 'Operation failed');
      }
    } catch (error) {
      setMessage('Network error: ' + error.message);
    }
  };

  const handleLogout = () => {
    setToken(null);
    localStorage.removeItem('token');
    setMessage('Logged out successfully');
  };

  if (token) {
    return (
      <div style={{ padding: '40px', maxWidth: '600px', margin: '0 auto', fontFamily: 'sans-serif' }}>
        <h1>✅ You are logged in!</h1>
        <p>Token: {token.substring(0, 20)}...</p>
        <button onClick={handleLogout} style={{ padding: '10px 20px', marginTop: '20px' }}>
          Logout
        </button>
        <div style={{ marginTop: '30px', padding: '20px', background: '#f0f0f0' }}>
          <h2>Next Steps:</h2>
          <ul>
            <li>The backend is running at localhost:3000</li>
            <li>You can now make authenticated API calls</li>
            <li>Build your custom frontend using this token</li>
            <li>See API documentation in README.md</li>
          </ul>
        </div>
      </div>
    );
  }

  return (
    <div style={{ 
      minHeight: '100vh', 
      display: 'flex', 
      alignItems: 'center', 
      justifyContent: 'center',
      background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
      fontFamily: 'sans-serif'
    }}>
      <div style={{ 
        background: 'white', 
        padding: '40px', 
        borderRadius: '10px', 
        maxWidth: '400px',
        width: '100%',
        boxShadow: '0 10px 40px rgba(0,0,0,0.2)'
      }}>
        <h1 style={{ textAlign: 'center', marginBottom: '30px' }}>
          🚀 Kin2 Workforce
        </h1>
        
        <div style={{ display: 'flex', marginBottom: '20px' }}>
          <button 
            onClick={() => setIsLogin(true)}
            style={{
              flex: 1,
              padding: '10px',
              border: 'none',
              background: isLogin ? '#667eea' : '#e0e0e0',
              color: isLogin ? 'white' : 'black',
              cursor: 'pointer',
              borderRadius: '5px 0 0 5px'
            }}
          >
            Login
          </button>
          <button 
            onClick={() => setIsLogin(false)}
            style={{
              flex: 1,
              padding: '10px',
              border: 'none',
              background: !isLogin ? '#667eea' : '#e0e0e0',
              color: !isLogin ? 'white' : 'black',
              cursor: 'pointer',
              borderRadius: '0 5px 5px 0'
            }}
          >
            Register
          </button>
        </div>

        <form onSubmit={handleSubmit}>
          {!isLogin && (
            <>
              <input
                type="text"
                placeholder="First Name"
                value={firstName}
                onChange={(e) => setFirstName(e.target.value)}
                required
                style={{ 
                  width: '100%', 
                  padding: '12px', 
                  marginBottom: '15px',
                  border: '1px solid #ddd',
                  borderRadius: '5px',
                  boxSizing: 'border-box'
                }}
              />
              <input
                type="text"
                placeholder="Last Name"
                value={lastName}
                onChange={(e) => setLastName(e.target.value)}
                required
                style={{ 
                  width: '100%', 
                  padding: '12px', 
                  marginBottom: '15px',
                  border: '1px solid #ddd',
                  borderRadius: '5px',
                  boxSizing: 'border-box'
                }}
              />
              <select
                value={role}
                onChange={(e) => setRole(e.target.value)}
                style={{ 
                  width: '100%', 
                  padding: '12px', 
                  marginBottom: '15px',
                  border: '1px solid #ddd',
                  borderRadius: '5px',
                  boxSizing: 'border-box'
                }}
              >
                <option value="WORKER">Worker</option>
                <option value="EMPLOYER">Employer</option>
                <option value="VOLUNTEER">Volunteer</option>
                <option value="FREELANCER">Freelancer</option>
              </select>
            </>
          )}
          
          <input
            type="email"
            placeholder="Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
            style={{ 
              width: '100%', 
              padding: '12px', 
              marginBottom: '15px',
              border: '1px solid #ddd',
              borderRadius: '5px',
              boxSizing: 'border-box'
            }}
          />
          
          <input
            type="password"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
            style={{ 
              width: '100%', 
              padding: '12px', 
              marginBottom: '20px',
              border: '1px solid #ddd',
              borderRadius: '5px',
              boxSizing: 'border-box'
            }}
          />
          
          <button 
            type="submit"
            style={{
              width: '100%',
              padding: '12px',
              background: '#667eea',
              color: 'white',
              border: 'none',
              borderRadius: '5px',
              fontSize: '16px',
              cursor: 'pointer'
            }}
          >
            {isLogin ? 'Login' : 'Register'}
          </button>
        </form>

        {message && (
          <div style={{
            marginTop: '20px',
            padding: '10px',
            background: message.includes('Success') ? '#d4edda' : '#f8d7da',
            borderRadius: '5px',
            textAlign: 'center'
          }}>
            {message}
          </div>
        )}
      </div>
    </div>
  );
}

export default App;
