const express = require('express'); const router = express.Router(); const { authenticate, authorize } = require('../middleware/auth'); module.exports = router;
