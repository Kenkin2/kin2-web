const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const { body, validationResult } = require('express-validator');
const { PrismaClient } = require('@prisma/client');
const { 
  generateToken, 
  generateRefreshToken, 
  verifyRefreshToken,
  revokeRefreshToken,
  authenticate 
} = require('../middleware/auth');

const prisma = new PrismaClient();

// ==================== REGISTER ====================

router.post('/register', [
  body('email').isEmail().normalizeEmail(),
  body('password').isLength({ min: 8 }),
  body('firstName').trim().notEmpty(),
  body('lastName').trim().notEmpty(),
  body('role').isIn(['EMPLOYER', 'WORKER', 'VOLUNTEER', 'FREELANCER', 'SELLER'])
], async (req, res) => {
  try {
    // Validate input
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { email, password, firstName, lastName, role } = req.body;

    // Check if user exists
    const existingUser = await prisma.user.findUnique({
      where: { email }
    });

    if (existingUser) {
      return res.status(400).json({ 
        error: 'Email already registered',
        message: 'An account with this email already exists' 
      });
    }

    // Hash password
    const passwordHash = await bcrypt.hash(password, 10);

    // Create user with profile
    const user = await prisma.user.create({
      data: {
        email,
        passwordHash,
        role,
        profile: {
          create: {
            firstName,
            lastName,
            displayName: `${firstName} ${lastName}`
          }
        }
      },
      include: {
        profile: true
      }
    });

    // Create role-specific profile
    switch (role) {
      case 'EMPLOYER':
        await prisma.employer.create({
          data: {
            userId: user.id,
            companyName: `${firstName}'s Company`, // Placeholder
            industry: 'OTHER',
            size: 'MICRO',
            contactName: `${firstName} ${lastName}`,
            contactEmail: email,
            contactPhone: ''
          }
        });
        break;
      
      case 'WORKER':
        await prisma.worker.create({
          data: {
            userId: user.id
          }
        });
        break;

      case 'VOLUNTEER':
        await prisma.volunteer.create({
          data: {
            userId: user.id
          }
        });
        break;

      case 'FREELANCER':
        await prisma.freelancer.create({
          data: {
            userId: user.id,
            title: 'Freelancer'
          }
        });
        break;

      case 'SELLER':
        await prisma.seller.create({
          data: {
            userId: user.id,
            storeName: `${firstName}'s Store`,
            category: 'OTHER'
          }
        });
        break;
    }

    // Generate tokens
    const accessToken = generateToken(user.id);
    const refreshToken = await generateRefreshToken(user.id);

    // Remove password from response
    const { passwordHash: _, ...userWithoutPassword } = user;

    res.status(201).json({
      message: 'Registration successful',
      user: userWithoutPassword,
      accessToken,
      refreshToken
    });

  } catch (error) {
    console.error('Registration error:', error);
    res.status(500).json({ 
      error: 'Registration failed', 
      message: error.message 
    });
  }
});

// ==================== LOGIN ====================

router.post('/login', [
  body('email').isEmail().normalizeEmail(),
  body('password').notEmpty()
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { email, password } = req.body;

    // Find user
    const user = await prisma.user.findUnique({
      where: { email },
      include: {
        profile: true,
        employerProfile: true,
        workerProfile: true,
        volunteerProfile: true,
        freelancerProfile: true,
        sellerProfile: true
      }
    });

    if (!user) {
      return res.status(401).json({ 
        error: 'Invalid credentials',
        message: 'Email or password is incorrect' 
      });
    }

    // Check password
    const isValidPassword = await bcrypt.compare(password, user.passwordHash);
    
    if (!isValidPassword) {
      return res.status(401).json({ 
        error: 'Invalid credentials',
        message: 'Email or password is incorrect' 
      });
    }

    // Check account status
    if (user.status !== 'ACTIVE') {
      return res.status(403).json({ 
        error: 'Account inactive',
        message: `Your account is ${user.status.toLowerCase()}` 
      });
    }

    // Update last login
    await prisma.user.update({
      where: { id: user.id },
      data: { lastLoginAt: new Date() }
    });

    // Generate tokens
    const accessToken = generateToken(user.id);
    const refreshToken = await generateRefreshToken(user.id);

    // Remove password from response
    const { passwordHash: _, ...userWithoutPassword } = user;

    res.json({
      message: 'Login successful',
      user: userWithoutPassword,
      accessToken,
      refreshToken
    });

  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ 
      error: 'Login failed', 
      message: error.message 
    });
  }
});

// ==================== REFRESH TOKEN ====================

router.post('/refresh', async (req, res) => {
  try {
    const { refreshToken } = req.body;

    if (!refreshToken) {
      return res.status(400).json({ 
        error: 'Missing token',
        message: 'Refresh token is required' 
      });
    }

    // Verify refresh token
    const userId = await verifyRefreshToken(refreshToken);

    // Generate new tokens
    const newAccessToken = generateToken(userId);
    const newRefreshToken = await generateRefreshToken(userId);

    // Revoke old refresh token
    await revokeRefreshToken(refreshToken);

    res.json({
      accessToken: newAccessToken,
      refreshToken: newRefreshToken
    });

  } catch (error) {
    res.status(401).json({ 
      error: 'Invalid token',
      message: error.message 
    });
  }
});

// ==================== LOGOUT ====================

router.post('/logout', authenticate, async (req, res) => {
  try {
    const { refreshToken } = req.body;

    if (refreshToken) {
      await revokeRefreshToken(refreshToken);
    }

    res.json({ message: 'Logout successful' });

  } catch (error) {
    res.status(500).json({ 
      error: 'Logout failed', 
      message: error.message 
    });
  }
});

// ==================== GET CURRENT USER ====================

router.get('/me', authenticate, async (req, res) => {
  try {
    const user = await prisma.user.findUnique({
      where: { id: req.userId },
      include: {
        profile: true,
        employerProfile: true,
        workerProfile: true,
        volunteerProfile: true,
        freelancerProfile: true,
        sellerProfile: true
      }
    });

    const { passwordHash: _, ...userWithoutPassword } = user;

    res.json(userWithoutPassword);

  } catch (error) {
    res.status(500).json({ 
      error: 'Failed to fetch user', 
      message: error.message 
    });
  }
});

// ==================== REQUEST PASSWORD RESET ====================

router.post('/forgot-password', [
  body('email').isEmail().normalizeEmail()
], async (req, res) => {
  try {
    const { email } = req.body;

    const user = await prisma.user.findUnique({
      where: { email }
    });

    if (!user) {
      // Don't reveal if email exists
      return res.json({ 
        message: 'If an account exists, a password reset link has been sent' 
      });
    }

    // Generate reset token (24 hours)
    const resetToken = generateToken(user.id, '24h');

    // In production, send email with reset link
    // await emailService.sendPasswordReset(email, resetToken);

    res.json({ 
      message: 'Password reset link sent',
      // For development only:
      ...(process.env.NODE_ENV === 'development' && { resetToken })
    });

  } catch (error) {
    res.status(500).json({ 
      error: 'Failed to process request', 
      message: error.message 
    });
  }
});

// ==================== RESET PASSWORD ====================

router.post('/reset-password', [
  body('token').notEmpty(),
  body('newPassword').isLength({ min: 8 })
], async (req, res) => {
  try {
    const { token, newPassword } = req.body;

    // Verify token
    const jwt = require('jsonwebtoken');
    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'your-secret-key-change-in-production');

    // Hash new password
    const passwordHash = await bcrypt.hash(newPassword, 10);

    // Update password
    await prisma.user.update({
      where: { id: decoded.userId },
      data: { passwordHash }
    });

    res.json({ message: 'Password reset successful' });

  } catch (error) {
    res.status(400).json({ 
      error: 'Invalid or expired token', 
      message: error.message 
    });
  }
});

// ==================== VERIFY EMAIL ====================

router.post('/verify-email', [
  body('token').notEmpty()
], async (req, res) => {
  try {
    const { token } = req.body;

    // Verify token
    const jwt = require('jsonwebtoken');
    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'your-secret-key-change-in-production');

    // Update user
    await prisma.user.update({
      where: { id: decoded.userId },
      data: { emailVerified: true }
    });

    res.json({ message: 'Email verified successfully' });

  } catch (error) {
    res.status(400).json({ 
      error: 'Invalid or expired token', 
      message: error.message 
    });
  }
});

module.exports = router;
