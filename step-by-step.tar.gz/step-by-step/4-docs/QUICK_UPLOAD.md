# 🚀 Quick GitHub Upload Commands

Copy and paste these commands to upload your project to GitHub in under 2 minutes!

## Step 1: Create Repository on GitHub
1. Go to: https://github.com/new
2. Repository name: `kin2-workforce-platform`
3. Keep everything else default
4. Click "Create repository"

## Step 2: Upload Your Code

```bash
# Navigate to your project folder
cd kin2-workforce-platform

# Initialize git
git init

# Add all files
git add .

# Create first commit
git commit -m "Initial commit: Kin2 Workforce Platform v2.5.0"

# Add your GitHub repository (REPLACE YOUR_USERNAME)
git remote add origin https://github.com/YOUR_USERNAME/kin2-workforce-platform.git

# Push to GitHub
git branch -M main
git push -u origin main
```

## Step 3: Enter Credentials

When prompted:
- **Username**: Your GitHub username
- **Password**: Your Personal Access Token (NOT your GitHub password)

### Get Personal Access Token:
1. Go to: https://github.com/settings/tokens
2. Click "Generate new token" → "Classic"
3. Name it: "Kin2 Upload"
4. Check: ☑️ repo (full control)
5. Click "Generate token"
6. **COPY IT** - you won't see it again!
7. Use this as password when pushing

## ✅ Done!

Visit: `https://github.com/YOUR_USERNAME/kin2-workforce-platform`

---

## 🔄 Making Updates Later

```bash
# After making changes
git add .
git commit -m "Description of what you changed"
git push
```

## 🆘 Troubleshooting

### "Permission denied"
→ Use Personal Access Token, not password

### "Repository not found"
→ Check you created the repo on GitHub first
→ Check the remote URL: `git remote -v`

### "Large files"
→ Don't worry, .gitignore will exclude them
→ Run: `git rm -r --cached node_modules/` if needed

---

**Remember:**
- ✅ Replace YOUR_USERNAME with your actual GitHub username
- ✅ Use Personal Access Token (not password)
- ❌ Never commit .env files or API keys

That's it! Your project will be on GitHub in 2 minutes! 🎉
