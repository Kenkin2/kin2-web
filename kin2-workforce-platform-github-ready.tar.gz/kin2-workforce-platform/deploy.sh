#!/bin/bash

# ==================== KIN2 WORKFORCE PLATFORM ====================
# Production Deployment Script
# ================================================================

set -e  # Exit on error

echo "🚀 Kin2 Workforce Platform - Deployment Script"
echo "================================================"
echo ""

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Check if .env exists
if [ ! -f backend/.env ]; then
    echo -e "${RED}❌ Error: backend/.env file not found${NC}"
    echo "Please copy backend/.env.example to backend/.env and configure it"
    exit 1
fi

# Load environment variables
source backend/.env

echo -e "${GREEN}✓${NC} Environment loaded"

# Check Node.js version
NODE_VERSION=$(node -v | cut -d'v' -f2 | cut -d'.' -f1)
if [ "$NODE_VERSION" -lt 20 ]; then
    echo -e "${RED}❌ Error: Node.js 20+ required (found v$NODE_VERSION)${NC}"
    exit 1
fi
echo -e "${GREEN}✓${NC} Node.js version: $(node -v)"

# Check if DATABASE_URL is set
if [ -z "$DATABASE_URL" ]; then
    echo -e "${RED}❌ Error: DATABASE_URL not set in .env${NC}"
    exit 1
fi
echo -e "${GREEN}✓${NC} Database URL configured"

# Install backend dependencies
echo ""
echo "📦 Installing backend dependencies..."
cd backend
npm install --production=false
echo -e "${GREEN}✓${NC} Backend dependencies installed"

# Generate Prisma Client
echo ""
echo "🔧 Generating Prisma Client..."
npx prisma generate
echo -e "${GREEN}✓${NC} Prisma Client generated"

# Run database migrations
echo ""
echo "🗄️  Running database migrations..."
if [ "$NODE_ENV" = "production" ]; then
    npx prisma migrate deploy
else
    npx prisma db push
fi
echo -e "${GREEN}✓${NC} Database migrations complete"

# Seed database (optional)
if [ "$AUTO_SEED" = "true" ]; then
    echo ""
    echo "🌱 Seeding database..."
    npm run db:seed || echo -e "${YELLOW}⚠${NC}  Seeding skipped (no seed file)"
fi

# Build frontend
echo ""
echo "🎨 Building frontend..."
cd ../frontend
npm install
npm run build
echo -e "${GREEN}✓${NC} Frontend built successfully"

# Copy frontend build to backend
echo ""
echo "📋 Copying frontend build to backend..."
rm -rf ../backend/dist
cp -r dist ../backend/dist
echo -e "${GREEN}✓${NC} Frontend copied"

# Run tests (optional)
if [ "$RUN_TESTS" = "true" ]; then
    echo ""
    echo "🧪 Running tests..."
    cd ../backend
    npm test || echo -e "${YELLOW}⚠${NC}  Some tests failed"
fi

# Start the server
cd ../backend
echo ""
echo "================================================"
echo -e "${GREEN}✅ Deployment complete!${NC}"
echo ""
echo "To start the server:"
echo "  cd backend && npm start"
echo ""
echo "To start with PM2 (production):"
echo "  pm2 start backend/server.js --name kin2-workforce"
echo ""
echo "Health check:"
echo "  curl http://localhost:$PORT/health"
echo ""
echo "================================================"

# Optional: Start server automatically
if [ "$AUTO_START" = "true" ]; then
    echo ""
    echo "🚀 Starting server..."
    npm start
fi
